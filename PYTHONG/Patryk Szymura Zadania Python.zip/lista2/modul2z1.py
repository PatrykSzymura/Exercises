def whichSort(cho,list = []):
    
    if cho == 1:
        list.sort()
    else:
        list.sort()
        list.reverse()
    return list
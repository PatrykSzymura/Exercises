from test import Board

b = Board


class Game:
    def __init__(self) -> None:
        pass

    def menu():
        print("="*50)
        dist = "                    "
        print(f"\n{dist}MONOPOLY{dist}\n")
        print("="*50)
    
    def game_start():
        x = 0
    def game_save():
        pass
    def game_end():
        pass
gra = Game
gra.menu()   